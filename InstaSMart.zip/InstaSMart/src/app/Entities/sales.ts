
/**
 * The Sales Interface For the Sales
 */
export interface sales{
    id:number,
    name:string,
    category:string,
    details:string,
    offer:string,
    image:string
}
