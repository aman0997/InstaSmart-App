import { Injectable } from "@angular/core";

@Injectable(
  {providedIn:"root"}
)

/**
 * Root Effects For Initialization NGRX Effects
 */
export class AppEffects{
  constructor(){}
}
