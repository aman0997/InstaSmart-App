import { ProductState } from './product.reducer';
/**
 * The Interface For Product App State
 */
export interface ProductAppState{
  products:ProductState
}
