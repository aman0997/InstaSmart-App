import { SaleState } from "./sales.reducer";


/**
 * The Sales App State
 */
export interface SalesAppState{
  sales:SaleState
}
