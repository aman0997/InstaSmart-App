import { CartState } from './cart.reducer';

/**
 * The App Cartstate
 */
export interface cartAppState{
  carts:CartState
}
