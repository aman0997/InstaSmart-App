import { UserState } from './user.reducer';

/**
 * The User App State
 */
export interface UserAppState{
  users:UserState
}
